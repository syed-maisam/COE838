/* COE838 - System-on-Chip
 * Lab 4 - Custom DIVIDER IP for HPS/FPGA Systems
 * main.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <time.h>
#include <sys/mman.h>
#include <stdint.h>
#include "hwlib.h"
#include "socal/socal.h"
#include "socal/hps.h"
#include "socal/alt_gpio.h"
#include "hps_0.h"

/* Memory region used for lightweight HPS-to-FPGA bridge */
#define LW_SIZE         0x00200000
#define LWHPS2FPGA_BASE 0xff200000

/* Pointers to divider IP register blocks */
volatile uint32_t *div_control = NULL;
volatile uint32_t *div_data    = NULL;

/* Counters used to track test success */
int div_success = 0;
int div_total   = 0;


/* Reset the divider hardware block */
void reset_system() {
    alt_write_word(div_control + 1, 0x1);   // assert reset
    alt_write_word(div_control + 1, 0x0);   // release reset
    usleep(1000);
}


/* Send numerator/denominator inputs and trigger division */
void start_div(uint32_t numerator_val, uint32_t denominator_val) {

    alt_write_word(div_data + 0, denominator_val);
    alt_write_word(div_data + 1, numerator_val);

    /* Start pulse for the divider */
    alt_write_word(div_control + 0, 0x1);
    alt_write_word(div_control + 0, 0x0);
}


/* Read results from the divider and verify if its correct */
void read_output(uint32_t num_input, uint32_t den_input) {

    uint32_t quotient_val, remainder_val;
    uint32_t den_echo, num_echo;
    uint32_t expected_q, expected_r;

    /* Wait until hardware sets the DONE signal */
    while (!(alt_read_word(div_control + 2) & 0x1));

    /* Read divider outputs and echoed inputs */
    quotient_val = alt_read_word(div_data + 0);
    remainder_val = alt_read_word(div_data + 1);
    den_echo = alt_read_word(div_data + 2);
    num_echo = alt_read_word(div_data + 3);

    /* Compute expected result using software given specific software safety checks */
    if (den_input == 0) {
        expected_q = 0xFFFF;
        expected_r = num_input;
    }
    else if (num_input == 0) {
        expected_q = 0;
        expected_r = 0;
    }
    else if (num_input < den_input) {
        expected_q = 0;
        expected_r = num_input;
    }
    else {
        expected_q = num_input / den_input;
        expected_r = num_input % den_input;
    }

    printf("DIV Start       : Numerator = 0x%08X (%u), Denominator = 0x%08X (%u)\n",
           num_input, num_input, den_input, den_input);

    printf("DIV Result      : Quotient = 0x%08X (%u), Remainder = 0x%08X (%u)\n",
           quotient_val, quotient_val, remainder_val, remainder_val);

    printf("Expected Result : Quotient = 0x%08X (%u), Remainder = 0x%08X (%u)\n",
           expected_q, expected_q, expected_r, expected_r);

    /* Compare FPGA result with expected software result */
    if ((quotient_val == expected_q) && (remainder_val == expected_r)) {
        printf("[SUCCESS]\n");
        div_success++;
    } else {
        printf("[FAIL]\n");
    }

    div_total++;
    printf("------------------------------------------------\n");

    usleep(1000);
}


int main(int argc, char **argv) {

    int mem_fd;
    int case_idx;
    void *lw_virtual_base;

    div_success = 0;
    div_total   = 0;

    /* Open physical memory to access FPGA registers */
    mem_fd = open("/dev/mem", (O_RDWR | O_SYNC));
    if (mem_fd == -1) {
        printf("ERROR: could not open /dev/mem...\n");
        return 1;
    }

    /* Map FPGA lightweight bridge region into user space */
    lw_virtual_base = mmap(NULL, LW_SIZE,
                           (PROT_READ | PROT_WRITE),
                           MAP_SHARED,
                           mem_fd,
                           LWHPS2FPGA_BASE);

    if (lw_virtual_base == MAP_FAILED) {
        printf("ERROR: mmap() failed...\n");
        close(mem_fd);
        return 1;
    }

    /* Assign divider IP register addresses */
    div_control = lw_virtual_base + DIV_CONTROL_0_BASE;
    div_data    = lw_virtual_base + DIV_DATA_0_BASE;

    printf("------ FPGA Divider Test ------\n");
    printf("------>Finished initializing HPS/FPGA system<-------\n");

    /* Run through generated divider cases */
    for (case_idx = 0; case_idx < 30; case_idx++) {

        uint32_t numerator_val = case_idx * 8 + 5;
        uint32_t denominator_val = (case_idx % 9) + 1;

        reset_system();
        start_div(numerator_val, denominator_val);
        read_output(numerator_val, denominator_val);
    }

    /* Final summary of results */
    printf("Final Result: %d/%d correct\n", div_success, div_total);

    if (div_success == div_total) {
        printf("All tests passed.\n");
    } else {
        printf("Some tests failed.\n");
    }

    /* Cleanup memory mapping */
    if (munmap(lw_virtual_base, LW_SIZE) != 0) {
        printf("ERROR: munmap() failed...\n");
        close(mem_fd);
        return 1;
    }

    close(mem_fd);

    return 0;
}
