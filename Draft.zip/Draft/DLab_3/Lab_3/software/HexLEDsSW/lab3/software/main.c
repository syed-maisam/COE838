/* * main.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <time.h>
#include <sys/mman.h>
#include <stdbool.h>
#include <pthread.h>
#include <stdint.h>    // Added for uint32_t/uint8_t
#include "hwlib.h"
#include "socal/socal.h"
#include "socal/hps.h"
#include "socal/alt_gpio.h"
#include "hps_0.h"
#include "led.h"
#include "seg7.h"

#define LW_SIZE 0x00200000
#define LWHPS2FPGA_BASE 0xff200000

volatile uint32_t *h2p_lw_led_addr = NULL;
volatile uint32_t *h2p_lw_hex_addr = NULL;

// 1. Fixed: Changed signature to match pthread requirements
void *led_blink(void *arg){
    int i=0;
    while(1){
        printf("LED ON \r\n");
        for(i=0;i<=10;i++){
            LEDR_LightCount(i);
            usleep(100*1000);
        }

        printf("LED OFF \r\n");

        for(i=0;i<=10;i++){
            LEDR_OffCount(i);
            usleep(100*1000);
        }
    }
    return NULL;
}

// 2. Added placeholder for missing function
void display_msg(void) {
    printf("SEG7 display sequence complete.\n");
}

int main(int argc, char **argv){

    pthread_t id;
    int ret;
    void *virtual_base;
    int fd;

    if( ( fd = open( "/dev/mem", ( O_RDWR | O_SYNC ) ) ) == -1 ) {
        printf( "ERROR: could not open \"/dev/mem\"...\n" );
        return( 1 );
    }

    virtual_base = mmap( NULL, LW_SIZE, ( PROT_READ | PROT_WRITE ), MAP_SHARED, fd, LWHPS2FPGA_BASE);

    if( virtual_base == MAP_FAILED ) {
        printf( "ERROR: mmap() failed...\n" );
        close( fd );
        return(1);
    }

    // 3. Fixed: Cast virtual_base to (uint8_t *) to allow byte-wise offset addition
    h2p_lw_led_addr = (volatile uint32_t *)((uint8_t *)virtual_base + ((uint32_t)(LED_PIO_BASE)));
    h2p_lw_hex_addr = (volatile uint32_t *)((uint8_t *)virtual_base + ((uint32_t)(SEG7_IF_0_BASE)));

    // Fixed: Removed unnecessary (void *) cast, though it was harmless
    ret = pthread_create(&id, NULL, led_blink, NULL);

    if(ret != 0){
        printf("Create pthread error!\n");
        exit(1);
    }

    SEG7_All_Number();
    display_msg();

    pthread_join(id, NULL);

    if( munmap( virtual_base, LW_SIZE) != 0 ) {
        printf( "ERROR: munmap() failed...\n" );
        close( fd );
        return( 1 );
    }

    close( fd );
    return 0;
}
