################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../lab3/software/led.c \
../lab3/software/main.c \
../lab3/software/seg7.c 

OBJS += \
./lab3/software/led.o \
./lab3/software/main.o \
./lab3/software/seg7.o 

C_DEPS += \
./lab3/software/led.d \
./lab3/software/main.d \
./lab3/software/seg7.d 


# Each subdirectory must supply rules for building sources it contributes
lab3/software/%.o: ../lab3/software/%.c
	@echo 'Building file: $<'
	@echo 'Invoking: GCC C Compiler'
	arm-linux-gnueabihf-gcc -I/usr/local/Quartus-EDS-14.0/embedded/ip/altera/hps/altera_hps/hwlib/include -O0 -g3 -Wall -c -fmessage-length=0 -MMD -MP -MF"$(@:%.o=%.d)" -MT"$(@:%.o=%.d)" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


