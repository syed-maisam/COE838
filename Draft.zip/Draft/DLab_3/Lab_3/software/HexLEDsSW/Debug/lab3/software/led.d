lab3/software/led.d: ../lab3/software/led.c ../lab3/software/led.h \
 /usr/local/Quartus-EDS-14.0/embedded/ip/altera/hps/altera_hps/hwlib/include/hwlib.h \
 /usr/local/Quartus-EDS-14.0/embedded/ip/altera/hps/altera_hps/hwlib/include/alt_hwlibs_ver.h \
 /usr/local/Quartus-EDS-14.0/embedded/ip/altera/hps/altera_hps/hwlib/include/socal/socal.h \
 /usr/local/Quartus-EDS-14.0/embedded/ip/altera/hps/altera_hps/hwlib/include/socal/hps.h \
 /usr/local/Quartus-EDS-14.0/embedded/ip/altera/hps/altera_hps/hwlib/include/socal/alt_gpio.h

../lab3/software/led.h:

/usr/local/Quartus-EDS-14.0/embedded/ip/altera/hps/altera_hps/hwlib/include/hwlib.h:

/usr/local/Quartus-EDS-14.0/embedded/ip/altera/hps/altera_hps/hwlib/include/alt_hwlibs_ver.h:

/usr/local/Quartus-EDS-14.0/embedded/ip/altera/hps/altera_hps/hwlib/include/socal/socal.h:

/usr/local/Quartus-EDS-14.0/embedded/ip/altera/hps/altera_hps/hwlib/include/socal/hps.h:

/usr/local/Quartus-EDS-14.0/embedded/ip/altera/hps/altera_hps/hwlib/include/socal/alt_gpio.h:
