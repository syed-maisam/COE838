#ifndef BARREL_SHIFT_H
#define BARREL_SHIFT_H

#include "systemc.h"

//Use header files for modules to define ports and processes for systemC components
SC_MODULE(barrel_shift) {
    // Ports
    sc_in<sc_int<8>> din;             // Input data
    sc_in<bool> clk;                  // added clk signal 
    sc_in<sc_uint<3>> shift_amt;      // Shift amount (3-bit)
    sc_in<bool> enable;               // Enable signal
    sc_in<bool> left_right;           // Left/Right control (0 = left, 1 = right)
    sc_out<sc_int<8>> dout;           // Output data

    // Process
    void barrel_method();

    // Constructor
    SC_CTOR(barrel_shift) {
        SC_METHOD(barrel_method);
        sensitive << din << shift_amt << enable << left_right << clk.pos();
    }
};

#endif // BARREL_SHIFT_H
