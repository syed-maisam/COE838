#ifndef ALU_H
#define ALU_H

#include "systemc.h"
#include "barrel_shift.h"

SC_MODULE(ALU) {
    // Ports
    sc_in<sc_int<8>> A;               // Input A
    sc_in<sc_int<8>> B;               // Input B
    sc_in<sc_uint<3>> shift_amt;      // Shift amount (3-bit)
    sc_in<bool> en;                   // Enable signal for barrel shifter
    sc_in<bool> l_r;                  // Left/Right control for barrel shifter
    sc_in<bool> op;                   // ALU operation: 0 = Subtract, 1 = Add
    sc_in<bool> clk;                  // Clock signal
    sc_out<sc_int<8>> result;         // Output result
    sc_out<bool> C;                   // Carry flag
    sc_out<bool> V;                   // Overflow flag
    sc_out<bool> N;                   // Negative flag
    sc_out<bool> Z;                   // Zero flag

    // Internal Signal
    sc_signal<sc_int<8>> shifted_B;   // Intermediate signal for shifted B

    // Instance of Barrel Shifter
    barrel_shift* shifter;

    // Process
    void alu_calc(); // Corrected method name

    // Constructor
    SC_CTOR(ALU) {
        // Instantiate barrel shifter
        shifter = new barrel_shift("barrel_shift");
        shifter->din(B);
        shifter->shift_amt(shift_amt);
        shifter->enable(en);
        shifter->left_right(l_r);
        shifter->clk(clk);           // Connect the clock signal to the barrel shifter
        shifter->dout(shifted_B);

        SC_METHOD(alu_calc);
        sensitive << A << B << shifted_B << op;
    }

    // Destructor
    ~ALU() {
        delete shifter;
    }
};

#endif // ALU_H