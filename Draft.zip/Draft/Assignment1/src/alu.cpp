#include "alu.h"

void ALU::alu_calc() {
    sc_int<8> a = A.read();
    sc_int<8> b = (op.read() == 0) ? B.read() : shifted_B.read();
    sc_int<8> res;
    bool carry = false, overflow = false;

    if (op.read() == 0) { // Subtract
        res = a - b;
        carry = (a < b);
        overflow = ((a < 0 && b > 0 && res > 0) || (a > 0 && b < 0 && res < 0));
    } else { // Add
        res = a + b;
        carry = (res < a);
        overflow = ((a > 0 && b > 0 && res < 0) || (a < 0 && b < 0 && res > 0));
    }

    result.write(res);
    C.write(carry);
    V.write(overflow);
    N.write(res < 0);
    Z.write(res == 0);
}
