#ifndef TOP_MODULE_H
#define TOP_MODULE_H

#include "alu.h"
#include "barrel_shift.h"
#include <systemc.h>

// Top-level module for encapsulating the ALU and Barrel Shifter modules

SC_MODULE(TopModule) {
    // External Ports
    sc_in<bool> clk;                      // Clock
    sc_in<bool> shift_enable;             // Enable signal for barrel shifter
    sc_in<bool> shift_dir;                // Direction for barrel shifter (0 = left, 1 = right)
    sc_in<bool> alu_op;                   // ALU operation (0 = subtract, 1 = add)
    sc_in<bool> shift_l_pad, shift_r_pad; // Pads for left/right shifting

    sc_in<sc_int<8>> input_a;             // ALU input A
    sc_in<sc_int<8>> input_b;             // ALU input B (through barrel shifter)
    sc_in<sc_uint<3>> shift_amount;       // Barrel shifter shift amount

    sc_out<sc_int<8>> final_result;       // Output of ALU
    sc_out<bool> C, V, N, Z;              // PSR flags

    // Internal Signal
    sc_signal<sc_int<8>> shifted_b_input; // Output of barrel shifter connected to ALU B input

    // Submodules
    barrel_shift* shifter;                // Barrel shifter instance
    ALU* alu;                             // ALU instance

    SC_CTOR(TopModule) {
        // Instantiate Barrel Shifter
        shifter = new barrel_shift("BarrelShifter");
        shifter->clk(clk);
        shifter->enable(shift_enable);
        shifter->left_right(shift_dir);
        shifter->din(input_b);          // Barrel shifter gets its input from the ALU
        shifter->dout(shifted_b_input); // Connect the output of the barrel shifter to the ALU
        shifter->shift_amt(shift_amount); // Connect the shift amount to the barrel shifter

        // Instantiate ALU
        alu = new ALU("ALU"); // Instantiate the ALU
        alu->op(alu_op);
        alu->A(input_a);
        alu->B(shifted_b_input); // ALU gets its B input from the shifter
        alu->result(final_result); //
        alu->shift_amt(shift_amount); // Connect the shift amount to the ALU
        alu->en(shift_enable); // Connect the enable signal to the ALU
        alu->l_r(shift_dir); // Connect the left/right control to the ALU
        alu->clk(clk); // Connect the clock signal to the ALU
        alu->C(C); // Connect the carry flag to the ALU
        alu->V(V); // Connect the overflow flag to the ALU
        alu->N(N); // Connect the negative flag to the ALU
        alu->Z(Z); // Connect the zero flag to the ALU
    }

    ~TopModule() {
        delete shifter;
        delete alu;
    }
};

#endif