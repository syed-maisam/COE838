#include "barrel_shift.h"

void barrel_shift::barrel_method() {
    sc_int<8> data = din.read();
    if (enable.read() == 1) {
        if (left_right.read() == 0) { // Left shift
            dout.write(data << shift_amt.read());
        } else { // Right shift
            dout.write(data >> shift_amt.read());
        }
    } else {
        dout.write(data); // Pass-through when enable = 0
    }
}
