#ifndef INDEX_H
#define INDEX_H

// Control signal definitions
enum ControlSignal {
    ADD = 0,
    SUBTRACT = 1,
    SHIFT_LEFT = 2,
    SHIFT_RIGHT = 3
};

// Data type definitions
typedef sc_int<8> DataType; // 8-bit integer type

#endif // INDEX_H