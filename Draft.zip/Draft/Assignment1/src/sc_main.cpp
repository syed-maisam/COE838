#include <systemc.h>
#include "alu.h"
#include "barrel_shift.h"
#include "top_module.h"

// Connect the top module to the testbench and run test cases
int sc_main(int argc, char* argv[]) {
    // Instantiate the top-level module
    TopModule top("TopModule");

    // Create signals for the top module
    sc_clock clk("clk", 10, SC_NS, 0.5); // Clock signal with 10ns period and 50% duty cycle

    sc_signal<bool> shift_enable, shift_dir, alu_op, shift_l_pad, shift_r_pad;  // Signals for AKU system
    sc_signal<sc_int<8>> input_a, input_b; // ALU input A & B
    sc_signal<sc_uint<3>> shift_amount; // Shift amount
    sc_signal<sc_int<8>> final_result; // Final result
    sc_signal<bool> C, V, N, Z; // PSR flags

    // Connect signals to top module
    top.clk(clk);
    top.shift_enable(shift_enable);
    top.shift_dir(shift_dir);
    top.alu_op(alu_op);
    top.shift_l_pad(shift_l_pad);
    top.shift_r_pad(shift_r_pad);
    top.input_a(input_a);
    top.input_b(input_b);
    top.shift_amount(shift_amount);
    top.final_result(final_result);
    top.C(C);
    top.V(V);
    top.N(N);
    top.Z(Z);

    // Tracefile for waveform generation
    sc_trace_file* trace_file = sc_create_vcd_trace_file("alu_trace");
    trace_file->set_time_unit(1, SC_NS);

    // Add signals to trace file
    sc_trace(trace_file, clk, "clk");
    sc_trace(trace_file, shift_enable, "shift_enable");
    sc_trace(trace_file, shift_dir, "shift_dir");
    sc_trace(trace_file, alu_op, "alu_op");
    sc_trace(trace_file, shift_l_pad, "shift_l_pad");
    sc_trace(trace_file, shift_r_pad, "shift_r_pad");
    sc_trace(trace_file, input_a, "input_a");
    sc_trace(trace_file, input_b, "input_b");
    sc_trace(trace_file, shift_amount, "shift_amount");
    sc_trace(trace_file, final_result, "final_result");
    sc_trace(trace_file, C, "C");
    sc_trace(trace_file, V, "V");
    sc_trace(trace_file, N, "N");
    sc_trace(trace_file, Z, "Z");

    // Test cases
    std::cout << "Starting ALU Test Cases...\n";
    std::cout << "---------------------------\n";
    // Test 1: Addition with barrel shifter disabled
    input_a.write(10);
    input_b.write(5);
    shift_amount.write(0);
    shift_enable.write(0);  // Disable barrel shifter
    alu_op.write(1);  // Add
    sc_start(10, SC_NS);
    std::cout << "Test 1: A = 10, B = 5, Barrel disabled, Operation = Add. Result = "
              << final_result.read() << " C=" << C.read() << " V=" << V.read() << " N=" << N.read() << " Z=" << Z.read() << std::endl;

    // Test 2: Subtraction
    input_a.write(20);
    input_b.write(7);
    alu_op.write(0);  // Subtract
    sc_start(10, SC_NS);
    std::cout << "Test 2: A = 20, B = 7, Operation = Subtract. Result = "
              << final_result.read() << " C=" << C.read() << " V=" << V.read() << " N=" << N.read() << " Z=" << Z.read() << std::endl;

    // Test 3: Left shift and addition
    input_a.write(10);
    input_b.write(2);
    shift_amount.write(2);  // Shift left by 2
    shift_enable.write(1);         // Enable barrel shifter
    shift_dir.write(0);        // Left shift
    alu_op.write(1);         // Add
    sc_start(10, SC_NS);
    std::cout << "Test 3: A = 10, B = 2, Shift = Left by 2, Operation = Add. Result = "
              << final_result.read() << " C=" << C.read() << " V=" << V.read() << " N=" << N.read() << " Z=" << Z.read() << std::endl;

    // Test 4: Right shift and addition
    input_a.write(15);
    input_b.write(8);
    shift_amount.write(3);  // Shift right by 3
    shift_enable.write(1);         // Enable barrel shifter
    shift_dir.write(1);        // Right shift
    alu_op.write(1);         // Add
    sc_start(10, SC_NS);
    std::cout << "Test 4: A = 15, B = 8, Shift = Right by 3, Operation = Add. Result = "
              << final_result.read() << " C=" << C.read() << " V=" << V.read() << " N=" << N.read() << " Z=" << Z.read() << std::endl;

    // Test 5: Overflow detection (Addition)
    input_a.write(127);  // Maximum positive value for 8-bit signed integer
    input_b.write(1);
    shift_enable.write(0);   // Disable barrel shifter
    alu_op.write(1);   // Add
    sc_start(10, SC_NS);
    std::cout << "Test 5: A = 127, B = 1, Operation = Add (Overflow). Result = "
              << final_result.read() << " C=" << C.read() << " V=" << V.read() << " N=" << N.read() << " Z=" << Z.read() << std::endl;

    // Test 6: Overflow detection (Subtraction)
    input_a.write(-128); // Minimum negative value for 8-bit signed integer
    input_b.write(1);
    shift_enable.write(0);   // Disable barrel shifter
    alu_op.write(0);   // Subtract
    sc_start(10, SC_NS);
    std::cout << "Test 6: A = -128, B = 1, Operation = Subtract (Overflow). Result = "
              << final_result.read() << " C=" << C.read() << " V=" << V.read() << " N=" << N.read() << " Z=" << Z.read() << std::endl;

    // Test 7: Barrel shifter only (pass-through)
    input_a.write(50);
    input_b.write(25);
    shift_amount.write(0);  // No shift
    shift_enable.write(1);         // Enable barrel shifter
    shift_dir.write(0);        // Left/right doesn't matter (no shift)
    alu_op.write(1);         // Add
    sc_start(10, SC_NS);
    std::cout << "Test 7: A = 50, B = 25, Shift = None, Barrel enabled. Result = "
              << final_result.read() << " C=" << C.read() << " V=" << V.read() << " N=" << N.read() << " Z=" << Z.read() << std::endl;

    // Test 8: Complex case with left shift and large shift amount
    input_a.write(100);
    input_b.write(3);
    shift_amount.write(5);  // Shift left by 5
    shift_enable.write(1);         // Enable barrel shifter
    shift_dir.write(0);        // Left shift
    alu_op.write(1);         // Add
    sc_start(10, SC_NS);
    std::cout << "Test 8: A = 100, B = 3, Shift = Left by 5, Operation = Add. Result = "
              << final_result.read() << " C=" << C.read() << " V=" << V.read() << " N=" << N.read() << " Z=" << Z.read() << std::endl;

    // Test 9: Complex case with overflow
    input_a.write(127);
    input_b.write(127);
    shift_amount.write(0);  // No shift
    shift_enable.write(0);  // Disable barrel shifter
    alu_op.write(1);        // Add
    sc_start(10, SC_NS);
    std::cout << "Test 9: A = 127, B = 127, No Shifting, Operation = Add. Result = "
              << final_result.read() << " C=" << C.read() << " V=" << V.read() << " N=" << N.read() << " Z=" << Z.read() << std::endl;

    // Clean up
    sc_close_vcd_trace_file(trace_file);
    std::cout << "Simulation completed. Tracefile generated: alu_trace.vcd" << std::endl;

    return 0;
}
