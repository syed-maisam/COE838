# SystemC ALU Project

## Overview
This project implements an integer-based Arithmetic Logic Unit (ALU) using SystemC. The ALU supports addition and subtraction operations and incorporates a barrel shifter for input B, allowing for flexible data manipulation based on specified control signals.

## Project Structure
```
systemc-alu-project
├── src
│   ├── alu.cpp          # Implementation of the ALU class
│   ├── alu.h            # Header file for the ALU class
│   ├── barrelshift.cpp   # Implementation of the barrel shift functionality
│   ├── barrelshift.h     # Header file for the barrel shift class
│   ├── main.cpp          # Entry point for the application
│   └── types
│       └── index.h      # Custom types and constants
├── Makefile              # Build instructions for the project
└── README.md             # Project documentation
```

## Files Description
- **src/alu.cpp**: Contains the implementation of the ALU class, including methods for addition and subtraction based on the opcode. It handles input from the barrel shifter.
  
- **src/alu.h**: Defines the ALU class and its public methods, including `add`, `subtract`, and `process`, which take inputs A and B, and the opcode to perform the required operation.

- **src/barrelshift.cpp**: Implements the barrel shift functionality with the `barrel_shift` class and its method `barrel_method`, which shifts input B left or right based on control signals.

- **src/barrelshift.h**: Defines the `barrel_shift` class and its public methods for shifting input data and reading control signals for enabling the shift and determining the direction.

- **src/main.cpp**: Serves as the entry point for the application, initializing the SystemC simulation, instantiating the ALU and barrel shifter, and setting up necessary signals and test cases.

- **src/types/index.h**: Defines custom types or constants used throughout the project, such as control signal definitions and data types for inputs and outputs.

## Build Instructions
To build the project, navigate to the project directory and run the following command:

```
make
```

This will compile the source files and link them together to create the executable.

## Running the Simulation
After building the project, you can run the simulation with the following command:

```
./alu_simulation
```

## Test Cases
The project includes test cases to validate the functionality of the ALU and barrel shifter. Ensure to review the `main.cpp` file for specific test scenarios and expected outcomes.

## Conclusion
This SystemC ALU project demonstrates the integration of arithmetic operations with data manipulation through a barrel shifter, providing a comprehensive example of digital design using SystemC.