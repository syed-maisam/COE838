transcript on
if {[file exists rtl_work]} {
	vdel -lib rtl_work -all
}
vlib rtl_work
vmap work rtl_work

vlib soc_system
vmap soc_system soc_system
vlog -vlog01compat -work soc_system +incdir+/home/student2/t11ngo/Desktop/COE838/MD5/soc_system/synthesis/submodules {/home/student2/t11ngo/Desktop/COE838/MD5/soc_system/synthesis/submodules/altera_reset_controller.v}
vlog -vlog01compat -work soc_system +incdir+/home/student2/t11ngo/Desktop/COE838/MD5/soc_system/synthesis/submodules {/home/student2/t11ngo/Desktop/COE838/MD5/soc_system/synthesis/submodules/altera_reset_synchronizer.v}
vlog -vlog01compat -work soc_system +incdir+/home/student2/t11ngo/Desktop/COE838/MD5/soc_system/synthesis/submodules {/home/student2/t11ngo/Desktop/COE838/MD5/soc_system/synthesis/submodules/soc_system_mm_interconnect_0.v}
vlog -vlog01compat -work soc_system +incdir+/home/student2/t11ngo/Desktop/COE838/MD5/soc_system/synthesis/submodules {/home/student2/t11ngo/Desktop/COE838/MD5/soc_system/synthesis/submodules/soc_system_hps_0.v}
vlog -vlog01compat -work soc_system +incdir+/home/student2/t11ngo/Desktop/COE838/MD5/soc_system/synthesis/submodules {/home/student2/t11ngo/Desktop/COE838/MD5/soc_system/synthesis/submodules/soc_system_hps_0_hps_io.v}
vlog -vlog01compat -work soc_system +incdir+/home/student2/t11ngo/Desktop/COE838/MD5/soc_system/synthesis/submodules {/home/student2/t11ngo/Desktop/COE838/MD5/soc_system/synthesis/submodules/hps_sdram.v}
vlog -vlog01compat -work soc_system +incdir+/home/student2/t11ngo/Desktop/COE838/MD5/soc_system/synthesis/submodules {/home/student2/t11ngo/Desktop/COE838/MD5/soc_system/synthesis/submodules/hps_sdram_p0_altdqdqs.v}
vlog -vlog01compat -work soc_system +incdir+/home/student2/t11ngo/Desktop/COE838/MD5/soc_system/synthesis/submodules {/home/student2/t11ngo/Desktop/COE838/MD5/soc_system/synthesis/submodules/altera_mem_if_hhp_qseq_synth_top.v}
vlog -vlog01compat -work soc_system +incdir+/home/student2/t11ngo/Desktop/COE838/MD5/soc_system/synthesis/submodules {/home/student2/t11ngo/Desktop/COE838/MD5/soc_system/synthesis/submodules/hps_sdram_p0_generic_ddio.v}
vlog -vlog01compat -work soc_system +incdir+/home/student2/t11ngo/Desktop/COE838/MD5/soc_system/synthesis/submodules {/home/student2/t11ngo/Desktop/COE838/MD5/soc_system/synthesis/submodules/hps_sdram_p0_acv_hard_addr_cmd_pads.v}
vlog -vlog01compat -work soc_system +incdir+/home/student2/t11ngo/Desktop/COE838/MD5/soc_system/synthesis/submodules {/home/student2/t11ngo/Desktop/COE838/MD5/soc_system/synthesis/submodules/hps_sdram_p0_clock_pair_generator.v}
vlog -vlog01compat -work soc_system +incdir+/home/student2/t11ngo/Desktop/COE838/MD5/soc_system/synthesis/submodules {/home/student2/t11ngo/Desktop/COE838/MD5/soc_system/synthesis/submodules/hps_sdram_p0_acv_hard_io_pads.v}
vlog -vlog01compat -work soc_system +incdir+/home/student2/t11ngo/Desktop/COE838/MD5/soc_system/synthesis/submodules {/home/student2/t11ngo/Desktop/COE838/MD5/soc_system/synthesis/submodules/hps_sdram_p0_acv_hard_memphy.v}
vlog -vlog01compat -work soc_system +incdir+/home/student2/t11ngo/Desktop/COE838/MD5/soc_system/synthesis/submodules {/home/student2/t11ngo/Desktop/COE838/MD5/soc_system/synthesis/submodules/hps_sdram_p0_acv_ldc.v}
vlog -sv -work soc_system +incdir+/home/student2/t11ngo/Desktop/COE838/MD5/soc_system/synthesis/submodules {/home/student2/t11ngo/Desktop/COE838/MD5/soc_system/synthesis/submodules/altera_merlin_arbitrator.sv}
vlog -sv -work soc_system +incdir+/home/student2/t11ngo/Desktop/COE838/MD5/soc_system/synthesis/submodules {/home/student2/t11ngo/Desktop/COE838/MD5/soc_system/synthesis/submodules/soc_system_mm_interconnect_0_rsp_mux.sv}
vlog -sv -work soc_system +incdir+/home/student2/t11ngo/Desktop/COE838/MD5/soc_system/synthesis/submodules {/home/student2/t11ngo/Desktop/COE838/MD5/soc_system/synthesis/submodules/soc_system_mm_interconnect_0_rsp_demux.sv}
vlog -sv -work soc_system +incdir+/home/student2/t11ngo/Desktop/COE838/MD5/soc_system/synthesis/submodules {/home/student2/t11ngo/Desktop/COE838/MD5/soc_system/synthesis/submodules/soc_system_mm_interconnect_0_cmd_mux.sv}
vlog -sv -work soc_system +incdir+/home/student2/t11ngo/Desktop/COE838/MD5/soc_system/synthesis/submodules {/home/student2/t11ngo/Desktop/COE838/MD5/soc_system/synthesis/submodules/soc_system_mm_interconnect_0_cmd_demux.sv}
vlog -sv -work soc_system +incdir+/home/student2/t11ngo/Desktop/COE838/MD5/soc_system/synthesis/submodules {/home/student2/t11ngo/Desktop/COE838/MD5/soc_system/synthesis/submodules/altera_merlin_burst_adapter_13_1.sv}
vlog -sv -work soc_system +incdir+/home/student2/t11ngo/Desktop/COE838/MD5/soc_system/synthesis/submodules {/home/student2/t11ngo/Desktop/COE838/MD5/soc_system/synthesis/submodules/altera_merlin_burst_adapter.sv}
vlog -sv -work soc_system +incdir+/home/student2/t11ngo/Desktop/COE838/MD5/soc_system/synthesis/submodules {/home/student2/t11ngo/Desktop/COE838/MD5/soc_system/synthesis/submodules/altera_merlin_address_alignment.sv}
vlog -sv -work soc_system +incdir+/home/student2/t11ngo/Desktop/COE838/MD5/soc_system/synthesis/submodules {/home/student2/t11ngo/Desktop/COE838/MD5/soc_system/synthesis/submodules/altera_merlin_traffic_limiter.sv}
vlog -vlog01compat -work soc_system +incdir+/home/student2/t11ngo/Desktop/COE838/MD5/soc_system/synthesis/submodules {/home/student2/t11ngo/Desktop/COE838/MD5/soc_system/synthesis/submodules/altera_avalon_sc_fifo.v}
vlog -sv -work soc_system +incdir+/home/student2/t11ngo/Desktop/COE838/MD5/soc_system/synthesis/submodules {/home/student2/t11ngo/Desktop/COE838/MD5/soc_system/synthesis/submodules/soc_system_mm_interconnect_0_router_002.sv}
vlog -sv -work soc_system +incdir+/home/student2/t11ngo/Desktop/COE838/MD5/soc_system/synthesis/submodules {/home/student2/t11ngo/Desktop/COE838/MD5/soc_system/synthesis/submodules/soc_system_mm_interconnect_0_router.sv}
vlog -sv -work soc_system +incdir+/home/student2/t11ngo/Desktop/COE838/MD5/soc_system/synthesis/submodules {/home/student2/t11ngo/Desktop/COE838/MD5/soc_system/synthesis/submodules/altera_merlin_slave_agent.sv}
vlog -sv -work soc_system +incdir+/home/student2/t11ngo/Desktop/COE838/MD5/soc_system/synthesis/submodules {/home/student2/t11ngo/Desktop/COE838/MD5/soc_system/synthesis/submodules/altera_merlin_burst_uncompressor.sv}
vlog -sv -work soc_system +incdir+/home/student2/t11ngo/Desktop/COE838/MD5/soc_system/synthesis/submodules {/home/student2/t11ngo/Desktop/COE838/MD5/soc_system/synthesis/submodules/altera_merlin_axi_master_ni.sv}
vlog -sv -work soc_system +incdir+/home/student2/t11ngo/Desktop/COE838/MD5/soc_system/synthesis/submodules {/home/student2/t11ngo/Desktop/COE838/MD5/soc_system/synthesis/submodules/altera_merlin_slave_translator.sv}
vlog -sv -work soc_system +incdir+/home/student2/t11ngo/Desktop/COE838/MD5/soc_system/synthesis/submodules {/home/student2/t11ngo/Desktop/COE838/MD5/soc_system/synthesis/submodules/altera_mem_if_dll_cyclonev.sv}
vlog -sv -work soc_system +incdir+/home/student2/t11ngo/Desktop/COE838/MD5/soc_system/synthesis/submodules {/home/student2/t11ngo/Desktop/COE838/MD5/soc_system/synthesis/submodules/altera_mem_if_hard_memory_controller_top_cyclonev.sv}
vlog -sv -work soc_system +incdir+/home/student2/t11ngo/Desktop/COE838/MD5/soc_system/synthesis/submodules {/home/student2/t11ngo/Desktop/COE838/MD5/soc_system/synthesis/submodules/hps_sdram_pll.sv}
vlog -sv -work soc_system +incdir+/home/student2/t11ngo/Desktop/COE838/MD5/soc_system/synthesis/submodules {/home/student2/t11ngo/Desktop/COE838/MD5/soc_system/synthesis/submodules/hps_sdram_p0.sv}
vlog -sv -work soc_system +incdir+/home/student2/t11ngo/Desktop/COE838/MD5/soc_system/synthesis/submodules {/home/student2/t11ngo/Desktop/COE838/MD5/soc_system/synthesis/submodules/altera_mem_if_oct_cyclonev.sv}
vlog -sv -work soc_system +incdir+/home/student2/t11ngo/Desktop/COE838/MD5/soc_system/synthesis/submodules {/home/student2/t11ngo/Desktop/COE838/MD5/soc_system/synthesis/submodules/altdq_dqs2_acv_connect_to_hard_phy_cyclonev.sv}
vlog -sv -work soc_system +incdir+/home/student2/t11ngo/Desktop/COE838/MD5/soc_system/synthesis/submodules {/home/student2/t11ngo/Desktop/COE838/MD5/soc_system/synthesis/submodules/soc_system_hps_0_hps_io_border.sv}
vlog -sv -work soc_system +incdir+/home/student2/t11ngo/Desktop/COE838/MD5/soc_system/synthesis/submodules {/home/student2/t11ngo/Desktop/COE838/MD5/soc_system/synthesis/submodules/soc_system_hps_0_fpga_interfaces.sv}
vcom -93 -work soc_system {/home/student2/t11ngo/Desktop/COE838/MD5/soc_system/synthesis/soc_system.vhd}
vcom -93 -work soc_system {/home/student2/t11ngo/Desktop/COE838/MD5/soc_system/synthesis/submodules/md5_group_control.vhd}
vcom -93 -work soc_system {/home/student2/t11ngo/Desktop/COE838/MD5/soc_system/synthesis/submodules/md5_group_data.vhd}
vcom -93 -work work {/home/student2/t11ngo/Desktop/COE838/MD5/srom.vhd}
vcom -93 -work work {/home/student2/t11ngo/Desktop/COE838/MD5/mram.vhd}
vcom -93 -work work {/home/student2/t11ngo/Desktop/COE838/MD5/md5_unit.vhd}
vcom -93 -work work {/home/student2/t11ngo/Desktop/COE838/MD5/md5_group.vhd}
vcom -93 -work work {/home/student2/t11ngo/Desktop/COE838/MD5/leftrotate.vhd}
vcom -93 -work work {/home/student2/t11ngo/Desktop/COE838/MD5/krom.vhd}
vcom -93 -work work {/home/student2/t11ngo/Desktop/COE838/MD5/gcalc.vhd}
vcom -93 -work work {/home/student2/t11ngo/Desktop/COE838/MD5/fcalc.vhd}
vcom -93 -work work {/home/student2/t11ngo/Desktop/COE838/MD5/chunk_cruncher.vhd}
vcom -93 -work work {/home/student2/t11ngo/Desktop/COE838/MD5/md5.vhd}

